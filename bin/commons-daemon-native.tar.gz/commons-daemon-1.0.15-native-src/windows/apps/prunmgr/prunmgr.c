/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* ====================================================================
 * prunmgr -- Service Manager Application.
 * Contributed by Mladen Turk <mturk@apache.org>
 * 05 Aug 2003
 * ====================================================================
 */

/* Force the JNI vprintf functions */
#define _DEBUG_JNI  1
#include "apxwin.h"
#include "prunmgr.h"

LPAPXGUISTORE _gui_store  = NULL;
#define PRUNMGR_CLASS      TEXT("PRUNMGR")
#define TMNU_CONF          TEXT("Configure...")
#define TMNU_START         TEXT("Start service")
#define TMNU_STOP          TEXT("Stop service")
#define TMNU_EXIT          TEXT("Exit")
#define TMNU_ABOUT         TEXT("About")
#define TMNU_DUMP          TEXT("Thread Dump")

/* Display only Started/Paused status */
#define STAT_STARTED        TEXT("Started")
#define STAT_PAUSED         TEXT("Paused")
#define STAT_STOPPED        TEXT("Stopped")
#define STAT_DISABLED       TEXT("Disabled")
#define STAT_NONE           TEXT("")
#define STAT_SYSTEM         L"LocalSystem"

#define LOGL_ERROR          L"Error"
#define LOGL_DEBUG          L"Debug"
#define LOGL_INFO           L"Info"
#define LOGL_WARN           L"Warning"


#define START_AUTO           L"Automatic"
#define START_MANUAL         L"Manual"
#define START_DISABLED       L"Disabled"
#define START_BOOT           L"Boot"
#define START_SYSTEM         L"SystemInit"
#define EMPTY_PASSWORD       L"               "

#ifdef WIN64
#define KREG_WOW6432  KEY_WOW64_32KEY
#else
#define KREG_WOW6432  0
#endif

/* Main application pool */
APXHANDLE hPool     = NULL;
APXHANDLE hService  = NULL;
APXHANDLE hRegistry = NULL;
APXHANDLE hRegserv  = NULL;
HICON     hIcoRun   = NULL;
HICON     hIcoStop  = NULL;

LPAPXSERVENTRY _currentEntry = NULL;

BOOL      bEnableTry = FALSE;
DWORD     startPage  = 0;

static LPCWSTR  _s_log          = L"Log";
static LPCWSTR  _s_java         = L"Java";
static LPCWSTR  _s_start        = L"Start";
static LPCWSTR  _s_stop         = L"Stop";

/* Allowed prunmgr commands */
static LPCWSTR _commands[] = {
    L"ES",      /* 1 Manage Service (default)*/
    L"MS",      /* 2 Monitor Service */
    L"MR",      /* 3 Monitor Service and start if not runing */
    L"MQ",      /* 4 Quit all running Monitor applications */
    NULL
};

static LPCWSTR _altcmds[] = {
    L"manage",      /* 1 Manage Service (default)*/
    L"monitor",     /* 2 Monitor Service */
    L"start",       /* 3 Monitor Service and start if not runing */
    L"quit",        /* 4 Quit all running Monitor applications */
    NULL
};


/* Allowed procrun parameters */
static APXCMDLINEOPT _options[] = {
/* 0  */    { L"AllowMultiInstances", NULL, NULL,   APXCMDOPT_INT, NULL, 0},
            /* NULL terminate the array */
            { NULL }
};

/* Create RBUTTON try menu
 * Configure... (default, or lbutton dblclick)
 * Start <service name>
 * Stop  <service name>
 * Exit
 * Logo
 */
static void createRbuttonTryMenu(HWND hWnd)
{
    HMENU hMnu;
    POINT pt;
    BOOL canStop  = FALSE;
    BOOL canStart = FALSE;
    hMnu = CreatePopupMenu();

    if (_currentEntry) {
        if (_currentEntry->stServiceStatus.dwCurrentState == SERVICE_RUNNING) {
            if (_currentEntry->stServiceStatus.dwControlsAccepted & SERVICE_ACCEPT_STOP)
                canStop = TRUE;
        }
        else if (_currentEntry->stServiceStatus.dwCurrentState == SERVICE_STOPPED) {
            if (_currentEntry->lpConfig->dwStartType != SERVICE_DISABLED)
                canStart = TRUE;
        }
    }
    apxAppendMenuItem(hMnu, IDM_TM_CONFIG, TMNU_CONF,  TRUE, TRUE);
    apxAppendMenuItem(hMnu, IDM_TM_START,  TMNU_START, FALSE, canStart);
    apxAppendMenuItem(hMnu, IDM_TM_STOP,   TMNU_STOP,  FALSE, canStop);
    apxAppendMenuItem(hMnu, IDM_TM_DUMP,   TMNU_DUMP,  FALSE, canStop);
    apxAppendMenuItem(hMnu, IDM_TM_EXIT,   TMNU_EXIT,  FALSE, TRUE);
    apxAppendMenuItem(hMnu,    -1, NULL,   FALSE, FALSE);
    apxAppendMenuItem(hMnu, IDM_TM_ABOUT,  TMNU_ABOUT, FALSE, TRUE);

    /* Ensure we have a focus */
    if (!SetForegroundWindow(hWnd))
        SetForegroundWindow(NULL);
    GetCursorPos(&pt);
    /* Display the try menu */
    TrackPopupMenu(hMnu, TPM_LEFTALIGN | TPM_RIGHTBUTTON,
                   pt.x, pt.y, 0, hWnd, NULL);
    DestroyMenu(hMnu);
}

/* wParam progress dialog handle
 */
static BOOL __startServiceCallback(APXHANDLE hObject, UINT uMsg,
                                   WPARAM wParam, LPARAM lParam)
{
    HWND hDlg = (HWND)hObject;

    switch (uMsg) {
        case WM_USER+1:
            hDlg = (HWND)lParam;
            if (IS_INVALID_HANDLE(hService)) {
                EndDialog(hDlg, IDOK);
                PostMessage(_gui_store->hMainWnd, WM_COMMAND,
                            MAKEWPARAM(IDMS_REFRESH, 0), 0);
                return FALSE;
            }
            if (apxServiceControl(hService, SERVICE_CONTROL_CONTINUE, WM_USER+2,
                                  __startServiceCallback, hDlg)) {
                _currentEntry->stServiceStatus.dwCurrentState = SERVICE_RUNNING;
                _currentEntry->stStatusProcess.dwCurrentState = SERVICE_RUNNING;

            }
            EndDialog(hDlg, IDOK);
            PostMessage(_gui_store->hMainWnd, WM_COMMAND,
                        MAKEWPARAM(IDMS_REFRESH, 0), 0);
        break;
        case WM_USER+2:
            SendMessage(hDlg, WM_USER+1, 0, 0);
            Sleep(500);
            break;
    }
    return TRUE;
}

static BOOL __stopServiceCallback(APXHANDLE hObject, UINT uMsg,
                                   WPARAM wParam, LPARAM lParam)
{
    HWND hDlg = (HWND)hObject;

    switch (uMsg) {
        case WM_USER+1:
            hDlg = (HWND)lParam;
            if (IS_INVALID_HANDLE(hService))
                return FALSE;
            if (apxServiceControl(hService, SERVICE_CONTROL_STOP, WM_USER+2,
                                  __stopServiceCallback, hDlg)) {
            }
            EndDialog(hDlg, IDOK);
            PostMessage(_gui_store->hMainWnd, WM_COMMAND,
                        MAKEWPARAM(IDMS_REFRESH, 0), 0);
        break;
        case WM_USER+2:
            if (wParam == 4)
                AplCopyMemory(&_currentEntry->stServiceStatus,
                              (LPVOID)lParam, sizeof(SERVICE_STATUS));
            SendMessage(hDlg, WM_USER+1, 0, 0);
            Sleep(100);
            break;
    }
    return TRUE;
}

static BOOL __restartServiceCallback(APXHANDLE hObject, UINT uMsg,
                                     WPARAM wParam, LPARAM lParam)
{
    HWND hDlg = (HWND)hObject;
    switch (uMsg) {
        case WM_USER+1:
            hDlg = (HWND)lParam;
            if (IS_INVALID_HANDLE(hService))
                return FALSE;
            /* TODO: use 128 as controll code */
            if (apxServiceControl(hService, 128, WM_USER+2,
                                  __restartServiceCallback, hDlg)) {

            }
            EndDialog(hDlg, IDOK);
            PostMessage(_gui_store->hMainWnd, WM_COMMAND,
                        MAKEWPARAM(IDMS_REFRESH, 0), 0);
        break;
        case WM_USER+2:
            if (wParam == 4)
                AplCopyMemory(&_currentEntry->stServiceStatus,
                              (LPVOID)lParam, sizeof(SERVICE_STATUS));

            SendMessage(hDlg, WM_USER+1, 0, 0);
            Sleep(100);
            break;
    }
    return TRUE;
}

static BOOL __pauseServiceCallback(APXHANDLE hObject, UINT uMsg,
                                   WPARAM wParam, LPARAM lParam)
{
    HWND hDlg = (HWND)hObject;
    switch (uMsg) {
        case WM_USER+1:
            hDlg = (HWND)lParam;
            if (IS_INVALID_HANDLE(hService))
                return FALSE;
            if (apxServiceControl(hService, SERVICE_CONTROL_PAUSE, WM_USER+2,
                                  __pauseServiceCallback, hDlg)) {
            }
            EndDialog(hDlg, IDOK);
            PostMessage(_gui_store->hMainWnd, WM_COMMAND,
                        MAKEWPARAM(IDMS_REFRESH, 0), 0);
        break;
        case WM_USER+2:
            if (wParam == 4)
                AplCopyMemory(&_currentEntry->stServiceStatus,
                             (LPVOID)lParam, sizeof(SERVICE_STATUS));
            SendMessage(hDlg, WM_USER+1, 0, 0);
            Sleep(100);
            break;
    }
    return TRUE;
}

static DWORD  _propertyChanged;
static BOOL   _propertyOpened = FALSE;
static HWND   _propertyHwnd = NULL;
/* Service property pages */
int CALLBACK __propertyCallback(HWND hwndPropSheet, UINT uMsg, LPARAM lParam)
{
    switch(uMsg) {
        case PSCB_PRECREATE:
           {
                LPDLGTEMPLATE  lpTemplate = (LPDLGTEMPLATE)lParam;
                if (!(lpTemplate->style & WS_SYSMENU))
                    lpTemplate->style |= WS_SYSMENU;
                _propertyHwnd = hwndPropSheet;

                _propertyChanged = 0;
                _propertyOpened = TRUE;
                return TRUE;
            }
        break;
        case PSCB_INITIALIZED:
        break;
    }
    return TRUE;
}

BOOL __generalPropertySave(HWND hDlg)
{
    WCHAR szN[SIZ_RESLEN];
    WCHAR szD[SIZ_DESLEN];
    DWORD dwStartType = SERVICE_NO_CHANGE;
    int i;

    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 1);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;
    GetDlgItemTextW(hDlg, IDC_PPSGDISP, szN, SIZ_RESMAX);
    GetDlgItemTextW(hDlg, IDC_PPSGDESC, szD, SIZ_DESMAX);
    i = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_PPSGCMBST));
    if (i == 0)
        dwStartType = SERVICE_AUTO_START;
    else if (i == 1)
        dwStartType = SERVICE_DEMAND_START;
    else if (i == 2)
        dwStartType = SERVICE_DISABLED;
    apxServiceSetNames(hService, NULL, szN, szD, NULL, NULL);
    apxServiceSetOptions(hService, SERVICE_NO_CHANGE, dwStartType, SERVICE_NO_CHANGE);

    if (!(TST_BIT_FLAG(_propertyChanged, 2)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);

    return TRUE;
}

BOOL __generalLogonSave(HWND hDlg)
{
    WCHAR szU[SIZ_RESLEN];
    WCHAR szP[SIZ_RESLEN];
    WCHAR szC[SIZ_RESLEN];
    DWORD dwStartType = SERVICE_NO_CHANGE;

    if (!(TST_BIT_FLAG(_propertyChanged, 2)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 2);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;
    GetDlgItemTextW(hDlg, IDC_PPSLUSER,  szU, SIZ_RESMAX);
    GetDlgItemTextW(hDlg, IDC_PPSLPASS,  szP, SIZ_RESMAX);
    GetDlgItemTextW(hDlg, IDC_PPSLCPASS, szC, SIZ_RESMAX);

    if (lstrlenW(szU) && lstrcmpiW(szU, STAT_SYSTEM)) {
        if (szP[0] != L' ' &&  szC[0] != L' ' && !lstrcmpW(szP, szC)) {
            apxServiceSetNames(hService, NULL, NULL, NULL, szU, szP);
            lstrlcpyW(_currentEntry->szObjectName, SIZ_RESLEN, szU);
        }
        else {
            MessageBoxW(hDlg, apxLoadResourceW(IDS_VALIDPASS, 0),
                        apxLoadResourceW(IDS_APPLICATION, 1),
                        MB_OK | MB_ICONSTOP);
            return FALSE;
        }
    }
    else {
        apxServiceSetNames(hService, NULL, NULL, NULL, STAT_SYSTEM, L"");
        lstrlcpyW(_currentEntry->szObjectName, SIZ_RESLEN, STAT_SYSTEM);
        if (IsDlgButtonChecked(hDlg, IDC_PPSLID) == BST_CHECKED)
            apxServiceSetOptions(hService,
                _currentEntry->stServiceStatus.dwServiceType | SERVICE_INTERACTIVE_PROCESS,
                SERVICE_NO_CHANGE, SERVICE_NO_CHANGE);
        else
            apxServiceSetOptions(hService,
                _currentEntry->stServiceStatus.dwServiceType & ~SERVICE_INTERACTIVE_PROCESS,
                SERVICE_NO_CHANGE, SERVICE_NO_CHANGE);
    }
    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);
    return TRUE;
}

BOOL __generalLoggingSave(HWND hDlg)
{
    WCHAR szB[SIZ_DESLEN];

    if (!(TST_BIT_FLAG(_propertyChanged, 3)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 3);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;

    GetDlgItemTextW(hDlg, IDC_PPLGLEVEL,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"Level", szB);
    GetDlgItemTextW(hDlg, IDC_PPLGPATH,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"Path", szB);
    GetDlgItemTextW(hDlg, IDC_PPLGPREFIX,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"Prefix", szB);
    GetDlgItemTextW(hDlg, IDC_PPLGPIDFILE,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"PidFile", szB);
    GetDlgItemTextW(hDlg, IDC_PPLGSTDOUT,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"StdOutput", szB);
    GetDlgItemTextW(hDlg, IDC_PPLGSTDERR,  szB, SIZ_DESMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_log, L"StdError", szB);

    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);
    return TRUE;
}

BOOL __generalJvmSave(HWND hDlg)
{
    WCHAR szB[SIZ_HUGLEN];
    LPWSTR p, s;
    DWORD  l;
    if (!(TST_BIT_FLAG(_propertyChanged, 4)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 4);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;
    if (!IsDlgButtonChecked(hDlg, IDC_PPJAUTO)) {
        GetDlgItemTextW(hDlg, IDC_PPJJVM,  szB, SIZ_HUGMAX);
    }
    else
        lstrcpyW(szB, L"auto");
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_java, L"Jvm", szB);
    GetDlgItemTextW(hDlg, IDC_PPJCLASSPATH,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_java, L"Classpath", szB);

    l = GetWindowTextLength(GetDlgItem(hDlg, IDC_PPJOPTIONS));
    p = apxPoolAlloc(hPool, (l + 2) * sizeof(WCHAR));
    GetDlgItemTextW(hDlg, IDC_PPJOPTIONS,  p, l + 1);
    s = apxCRLFToMszW(hPool, p, &l);
    apxFree(p);
    apxRegistrySetMzStrW(hRegserv, APXREG_PARAMSOFTWARE,
                         _s_java, L"Options", s, l);
    if (!GetDlgItemTextW(hDlg, IDC_PPJMS,  szB, SIZ_HUGMAX))
        szB[0] = L'\0';

    apxRegistrySetNumW(hRegserv, APXREG_PARAMSOFTWARE, _s_java, L"JvmMs",
                       apxAtoulW(szB));
    if (!GetDlgItemTextW(hDlg, IDC_PPJMX,  szB, SIZ_DESMAX))
        szB[0] = L'\0';
    apxRegistrySetNumW(hRegserv, APXREG_PARAMSOFTWARE, _s_java, L"JvmMx",
                       apxAtoulW(szB));
    if (!GetDlgItemTextW(hDlg, IDC_PPJSS,  szB, SIZ_DESMAX))
        szB[0] = L'\0';
    apxRegistrySetNumW(hRegserv, APXREG_PARAMSOFTWARE, _s_java, L"JvmSs",
                       apxAtoulW(szB));
    apxFree(s);
    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);
    return TRUE;
}

BOOL __generalStartSave(HWND hDlg)
{
    WCHAR szB[SIZ_HUGLEN];
    LPWSTR p, s;
    DWORD  l;

    if (!(TST_BIT_FLAG(_propertyChanged, 5)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 5);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;

    GetDlgItemTextW(hDlg, IDC_PPRCLASS,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_start, L"Class", szB);
    GetDlgItemTextW(hDlg, IDC_PPRIMAGE,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_start, L"Image", szB);
    GetDlgItemTextW(hDlg, IDC_PPRWPATH,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_start, L"WorkingPath", szB);
    GetDlgItemTextW(hDlg, IDC_PPRMETHOD,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_start, L"Method", szB);
    GetDlgItemTextW(hDlg, IDC_PPRMODE,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_start, L"Mode", szB);

    l = GetWindowTextLength(GetDlgItem(hDlg, IDC_PPRARGS));
    p = apxPoolAlloc(hPool, (l + 2) * sizeof(WCHAR));
    GetDlgItemTextW(hDlg, IDC_PPRARGS,  p, l + 1);
    s = apxCRLFToMszW(hPool, p, &l);
    apxFree(p);
    apxRegistrySetMzStrW(hRegserv, APXREG_PARAMSOFTWARE,
                         _s_start, L"Params", s, l);
    apxFree(s);

    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);
    return TRUE;
}

BOOL __generalStopSave(HWND hDlg)
{
    WCHAR szB[SIZ_HUGLEN];
    LPWSTR p, s;
    DWORD  l;

    if (!(TST_BIT_FLAG(_propertyChanged, 6)))
        return TRUE;
    CLR_BIT_FLAG(_propertyChanged, 6);

    if (IS_INVALID_HANDLE(hService))
        return FALSE;

    GetDlgItemTextW(hDlg, IDC_PPSCLASS,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Class", szB);
    GetDlgItemTextW(hDlg, IDC_PPSIMAGE,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Image", szB);
    GetDlgItemTextW(hDlg, IDC_PPSWPATH,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"WorkingPath", szB);
    GetDlgItemTextW(hDlg, IDC_PPSMETHOD,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Method", szB);
    GetDlgItemTextW(hDlg, IDC_PPSTIMEOUT,  szB, SIZ_HUGMAX);
    apxRegistrySetNumW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Timeout", apxAtoulW(szB));
    GetDlgItemTextW(hDlg, IDC_PPSMODE,  szB, SIZ_HUGMAX);
    apxRegistrySetStrW(hRegserv, APXREG_PARAMSOFTWARE, _s_stop, L"Mode", szB);

    l = GetWindowTextLength(GetDlgItem(hDlg, IDC_PPSARGS));
    p = apxPoolAlloc(hPool, (l + 2) * sizeof(WCHAR));
    GetDlgItemTextW(hDlg, IDC_PPSARGS,  p, l + 1);
    s = apxCRLFToMszW(hPool, p, &l);
    apxFree(p);
    apxRegistrySetMzStrW(hRegserv, APXREG_PARAMSOFTWARE,
                         _s_stop, L"Params", s, l);
    apxFree(s);

    if (!(TST_BIT_FLAG(_propertyChanged, 1)))
        PostMessage(_gui_store->hMainWnd, WM_COMMAND, MAKEWPARAM(IDMS_REFRESH, 0), 0);
    return TRUE;
}

void __generalPropertyRefresh(HWND hDlg)
{

    Button_Enable(GetDlgItem(hDlg, IDC_PPSGSTART), FALSE);
    Button_Enable(GetDlgItem(hDlg, IDC_PPSGSTOP), FALSE);
    Button_Enable(GetDlgItem(hDlg, IDC_PPSGPAUSE), FALSE);
    Button_Enable(GetDlgItem(hDlg, IDC_PPSGRESTART), FALSE);
    switch (_currentEntry->stServiceStatus.dwCurrentState) {
        case SERVICE_RUNNING:
            if (_currentEntry->stServiceStatus.dwControlsAccepted & SERVICE_ACCEPT_STOP ||
                _currentEntry->lpConfig->dwStartType != SERVICE_DISABLED) {
                Button_Enable(GetDlgItem(hDlg, IDC_PPSGSTOP), TRUE);
                SetDlgItemText(hDlg, IDC_PPSGSTATUS, STAT_STARTED);
            }
            else
                SetDlgItemText(hDlg, IDC_PPSGSTATUS, STAT_DISABLED);
            if (_currentEntry->stServiceStatus.dwControlsAccepted & SERVICE_ACCEPT_PAUSE_CONTINUE) {
                Button_Enable(GetDlgItem(hDlg, IDC_PPSGPAUSE), TRUE);
                Button_Enable(GetDlgItem(hDlg, IDC_PPSGRESTART), TRUE);
            }
        break;
        case SERVICE_PAUSED:
            Button_Enable(GetDlgItem(hDlg, IDC_PPSGSTART), TRUE);
            Button_Enable(GetDlgItem(hDlg, IDC_PPSGRESTART), TRUE);
            SetDlgItemText(hDlg, IDC_PPSGSTATUS, STAT_PAUSED);
        break;
        case SERVICE_STOPPED:
            if (_currentEntry->lpConfig->dwStartType != SERVICE_DISABLED) {
                Button_Enable(GetDlgItem(hDlg, IDC_PPSGSTART), TRUE);
                SetDlgItemText(hDlg, IDC_PPSGSTATUS, STAT_STOPPED);
            }
            else
                SetDlgItemText(hDlg, IDC_PPSGSTATUS, STAT_DISABLED);
        break;
        default:
        break;
    }
}

static BOOL bpropCentered = FALSE;
static HWND _generalPropertyHwnd = NULL;

LRESULT CALLBACK __generalProperty(HWND hDlg,
                                   UINT uMessage,
                                   WPARAM wParam,
                                   LPARAM lParam)
{
    LPPSHNOTIFY lpShn;
    WCHAR       szBuf[SIZ_DESLEN];

    switch (uMessage) {
        case WM_INITDIALOG:
            {
                _generalPropertyHwnd = hDlg;
                if (!bEnableTry)
                    apxCenterWindow(GetParent(hDlg), NULL);
                else if (!bpropCentered)
                    apxCenterWindow(GetParent(hDlg), NULL);
                bpropCentered = TRUE;
                startPage = 0;
                if (!bEnableTry)
                    apxCenterWindow(GetParent(hDlg), NULL);
                SendMessage(GetDlgItem(hDlg, IDC_PPSGDISP), EM_LIMITTEXT, SIZ_RESMAX, 0);
                SendMessage(GetDlgItem(hDlg, IDC_PPSGDESC), EM_LIMITTEXT, SIZ_DESMAX, 0);

                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPSGCMBST), START_AUTO);
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPSGCMBST), START_MANUAL);
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPSGCMBST), START_DISABLED);
                if (_currentEntry->lpConfig->dwStartType == SERVICE_AUTO_START)
                    ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPSGCMBST), 0);
                else if (_currentEntry->lpConfig->dwStartType == SERVICE_DEMAND_START)
                    ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPSGCMBST), 1);
                else if (_currentEntry->lpConfig->dwStartType == SERVICE_DISABLED)
                    ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPSGCMBST), 2);

                SetDlgItemTextW(hDlg, IDC_PPSGNAME, _currentEntry->szServiceName);
                SetDlgItemTextW(hDlg, IDC_PPSGDISP, _currentEntry->lpConfig->lpDisplayName);
                SetDlgItemTextW(hDlg, IDC_PPSGDESC, _currentEntry->szServiceDescription);
                SetDlgItemTextW(hDlg, IDC_PPSGDEXE, _currentEntry->lpConfig->lpBinaryPathName);
                __generalPropertyRefresh(hDlg);
            }
        break;
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_PPSGCMBST:
                    if (HIWORD(wParam) == CBN_SELCHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 1);
                    }
                break;
                case IDC_PPSGDISP:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        GetDlgItemTextW(hDlg, IDC_PPSGDISP, szBuf, SIZ_RESMAX);
                        if (!lstrcmpW(szBuf, _currentEntry->lpConfig->lpDisplayName)) {
                            PropSheet_UnChanged(GetParent(hDlg), hDlg);
                            CLR_BIT_FLAG(_propertyChanged, 1);
                        }
                        else {
                            PropSheet_Changed(GetParent(hDlg), hDlg);
                            SET_BIT_FLAG(_propertyChanged, 1);
                        }
                    }
                break;
                case IDC_PPSGDESC:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        GetDlgItemTextW(hDlg, IDC_PPSGDESC, szBuf, SIZ_DESMAX);
                        if (!lstrcmpW(szBuf, _currentEntry->szServiceDescription)) {
                            PropSheet_UnChanged(GetParent(hDlg), hDlg);
                            CLR_BIT_FLAG(_propertyChanged, 1);
                        }
                        else {
                            PropSheet_Changed(GetParent(hDlg), hDlg);
                            SET_BIT_FLAG(_propertyChanged, 1);
                        }
                    }
                break;
                case IDC_PPSGSTART:
                    apxProgressBox(hDlg, apxLoadResource(IDS_HSSTART, 0),
                                   _currentEntry->lpConfig->lpDisplayName,
                                   __startServiceCallback, NULL);
                    __generalPropertyRefresh(hDlg);
                break;
                case IDC_PPSGSTOP:
                    apxProgressBox(hDlg, apxLoadResource(IDS_HSSTOP, 0),
                                   _currentEntry->lpConfig->lpDisplayName,
                                   __stopServiceCallback, NULL);
                    __generalPropertyRefresh(hDlg);
                break;
                case IDC_PPSGPAUSE:
                    apxProgressBox(hDlg, apxLoadResource(IDS_HSPAUSE, 0),
                                   _currentEntry->lpConfig->lpDisplayName,
                                   __pauseServiceCallback, NULL);
                    __generalPropertyRefresh(hDlg);
                break;
                case IDC_PPSGRESTART:
                    apxProgressBox(hDlg, apxLoadResource(IDS_HSRESTART, 0),
                                   _currentEntry->lpConfig->lpDisplayName,
                                   __restartServiceCallback, NULL);
                    __generalPropertyRefresh(hDlg);
                break;
            }
        break;
        case WM_NOTIFY:
            lpShn = (LPPSHNOTIFY )lParam;
            switch (lpShn->hdr.code) {
                case PSN_APPLY:   /* sent when OK or Apply button pressed */
                    if (__generalPropertySave(hDlg)) {
                        PropSheet_UnChanged(GetParent(hDlg), hDlg);
                    }
                    else {
                        SET_BIT_FLAG(_propertyChanged, 1);
                        SetWindowLong(hDlg, DWLP_MSGRESULT,
                                      PSNRET_INVALID_NOCHANGEPAGE);
                        return TRUE;
                    }

                break;
                default:
                break;
            }
        break;
        default:
        break;
    }

    return FALSE;
}

LRESULT CALLBACK __logonProperty(HWND hDlg,
                                 UINT uMessage,
                                 WPARAM wParam,
                                 LPARAM lParam)
{
    LPPSHNOTIFY lpShn;
    WCHAR       szBuf[SIZ_DESLEN];
    switch (uMessage) {
        case WM_INITDIALOG:
            {
                BOOL           bAccount = FALSE;
                startPage = 1;
                if (!bpropCentered)
                    apxCenterWindow(GetParent(hDlg), NULL);
                bpropCentered = TRUE;

                SendMessage(GetDlgItem(hDlg, IDC_PPSLUSER), EM_LIMITTEXT, 63, 0);
                SendMessage(GetDlgItem(hDlg, IDC_PPSLPASS), EM_LIMITTEXT, 63, 0);
                SendMessage(GetDlgItem(hDlg, IDC_PPSLCPASS), EM_LIMITTEXT, 63, 0);
                /* Check if we use LocalSystem or user defined account */
                if (lstrcmpiW(_currentEntry->szObjectName, STAT_SYSTEM)) {
                    bAccount = TRUE;
                    CheckRadioButton(hDlg, IDC_PPSLLS, IDC_PPSLUA, IDC_PPSLUA);
                    SetDlgItemTextW(hDlg, IDC_PPSLUSER, _currentEntry->szObjectName);
                    SetDlgItemTextW(hDlg, IDC_PPSLPASS, EMPTY_PASSWORD);
                    SetDlgItemTextW(hDlg, IDC_PPSLCPASS, EMPTY_PASSWORD);
                }
                else {
                    CheckRadioButton(hDlg, IDC_PPSLLS, IDC_PPSLUA, IDC_PPSLLS);
                    if (_currentEntry->lpConfig->dwServiceType &
                        SERVICE_INTERACTIVE_PROCESS)
                        CheckDlgButton(hDlg, IDC_PPSLID, BST_CHECKED);
                }
                EnableWindow(GetDlgItem(hDlg, IDC_PPSLID), !bAccount);
                EnableWindow(GetDlgItem(hDlg, IDC_PPSLUSER), bAccount);
                EnableWindow(GetDlgItem(hDlg, IDC_PPSLBROWSE), bAccount);
                EnableWindow(GetDlgItem(hDlg, IDL_PPSLPASS), bAccount);
                EnableWindow(GetDlgItem(hDlg, IDC_PPSLPASS), bAccount);
                EnableWindow(GetDlgItem(hDlg, IDL_PPSLCPASS), bAccount);
                EnableWindow(GetDlgItem(hDlg, IDC_PPSLCPASS), bAccount);
            }
        break;
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_PPSLLS:
                    SetDlgItemTextW(hDlg, IDC_PPSLUSER, L"");
                    SetDlgItemTextW(hDlg, IDC_PPSLPASS, L"");
                    SetDlgItemTextW(hDlg, IDC_PPSLCPASS, L"");
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLID), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLUSER), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLBROWSE), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDL_PPSLPASS), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLPASS), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDL_PPSLCPASS), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLCPASS), FALSE);
                    CheckRadioButton(hDlg, IDC_PPSLLS, IDC_PPSLUA, (INT)wParam);
                    if (lstrcmpiW(_currentEntry->szObjectName, STAT_SYSTEM)) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 2);
                    }
                    else {
                        PropSheet_UnChanged(GetParent(hDlg), hDlg);
                        CLR_BIT_FLAG(_propertyChanged, 2);
                    }
                    break;
                case IDC_PPSLUA:
                    SetDlgItemTextW(hDlg, IDC_PPSLUSER, _currentEntry->szObjectName);
                    SetDlgItemTextW(hDlg, IDC_PPSLPASS, EMPTY_PASSWORD);
                    SetDlgItemTextW(hDlg, IDC_PPSLCPASS, EMPTY_PASSWORD);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLID), FALSE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLUSER), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLBROWSE), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDL_PPSLPASS), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLPASS), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDL_PPSLCPASS), TRUE);
                    EnableWindow(GetDlgItem(hDlg, IDC_PPSLCPASS), TRUE);
                    CheckRadioButton(hDlg, IDC_PPSLLS, IDC_PPSLUA, (INT)wParam);
                    if (lstrcmpW(_currentEntry->szObjectName, STAT_SYSTEM)) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 2);
                    }
                    else {
                        PropSheet_UnChanged(GetParent(hDlg), hDlg);
                        CLR_BIT_FLAG(_propertyChanged, 2);
                    }
                    break;
                case IDC_PPSLID:
                    PropSheet_Changed(GetParent(hDlg), hDlg);
                    SET_BIT_FLAG(_propertyChanged, 2);
                break;
                case IDC_PPSLUSER:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        GetDlgItemTextW(hDlg, IDC_PPSLUSER, szBuf, SIZ_RESMAX);
                        if (!lstrcmpiW(szBuf, _currentEntry->szObjectName)) {
                            PropSheet_UnChanged(GetParent(hDlg), hDlg);
                            CLR_BIT_FLAG(_propertyChanged, 2);
                        }
                        else {
                            PropSheet_Changed(GetParent(hDlg), hDlg);
                            SET_BIT_FLAG(_propertyChanged, 2);
                        }
                    }
                break;
                case IDC_PPSLPASS:
                case IDC_PPSLCPASS:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        WCHAR szP[SIZ_RESLEN];
                        WCHAR szC[SIZ_RESLEN];
                        GetDlgItemTextW(hDlg, IDC_PPSLPASS, szP, SIZ_RESMAX);
                        GetDlgItemTextW(hDlg, IDC_PPSLCPASS, szC, SIZ_RESMAX);
                        /* check for valid password match */
                        if (szP[0] == L' ' &&  szC[0] == L' ') {
                            PropSheet_UnChanged(GetParent(hDlg), hDlg);
                            CLR_BIT_FLAG(_propertyChanged, 2);
                        }
                        else if (!lstrcmpW(szP, szC)) {
                            PropSheet_Changed(GetParent(hDlg), hDlg);
                            SET_BIT_FLAG(_propertyChanged, 2);
                        }
                    }
                break;
                case IDC_PPSLBROWSE:
                    {
                        WCHAR szUser[SIZ_RESLEN];
                        if (apxDlgSelectUser(hDlg, szUser))
                            SetDlgItemTextW(hDlg, IDC_PPSLUSER, szUser);
                    }
                break;
            }
        break;
        case WM_NOTIFY:
            lpShn = (LPPSHNOTIFY )lParam;
            switch (lpShn->hdr.code) {
                case PSN_APPLY:   /* sent when OK or Apply button pressed */
                    if (__generalLogonSave(hDlg))
                        PropSheet_UnChanged(GetParent(hDlg), hDlg);
                    else {
                        SET_BIT_FLAG(_propertyChanged, 2);
                        SetWindowLong(hDlg, DWLP_MSGRESULT,
                                      PSNRET_INVALID_NOCHANGEPAGE);
                        return TRUE;
                    }

                break;
            }
        break;

        default:
        break;
    }
    return FALSE;
}

LRESULT CALLBACK __loggingProperty(HWND hDlg,
                                   UINT uMessage,
                                   WPARAM wParam,
                                   LPARAM lParam)
{
    LPPSHNOTIFY lpShn;
    LPWSTR      lpBuf;

    switch (uMessage) {
        case WM_INITDIALOG:
            {
                LPWSTR b;
                startPage = 2;
                if (!bpropCentered)
                    apxCenterWindow(GetParent(hDlg), NULL);
                bpropCentered = TRUE;
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPLGLEVEL), LOGL_ERROR);
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPLGLEVEL), LOGL_INFO);
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPLGLEVEL), LOGL_WARN);
                ComboBox_AddStringW(GetDlgItem(hDlg, IDC_PPLGLEVEL), LOGL_DEBUG);
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"Level")) != NULL) {
                    if (!lstrcmpiW(b, LOGL_ERROR))
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPLGLEVEL), 0);
                    else if (!lstrcmpiW(b, LOGL_INFO))
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPLGLEVEL), 1);
                    else if (!lstrcmpiW(b, LOGL_WARN))
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPLGLEVEL), 2);
                    else
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPLGLEVEL), 3);
                    apxFree(b);
                }
                else
                    ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_PPLGLEVEL), 1);
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"Path")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPLGPATH, b);
                    apxFree(b);
                }
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"Prefix")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPLGPREFIX, b);
                    apxFree(b);
                }
                else
                    SetDlgItemTextW(hDlg, IDC_PPLGPREFIX, L"commons-daemon");
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"PidFile")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPLGPIDFILE, b);
                    apxFree(b);
                }
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"StdOutput")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPLGSTDOUT, b);
                    apxFree(b);
                }
                if ((b = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_log, L"StdError")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPLGSTDERR, b);
                    apxFree(b);
                }
            }
        break;
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_PPLGLEVEL:
                    if (HIWORD(wParam) == CBN_SELCHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGPATH:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGPREFIX:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGPIDFILE:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGSTDERR:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGSTDOUT:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGBPATH:
                    lpBuf = apxBrowseForFolderW(hDlg, apxLoadResourceW(IDS_LGPATHTITLE, 0),
                                                NULL);
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPLGPATH, lpBuf);
                        apxFree(lpBuf);
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGBSTDOUT:
                    lpBuf = apxGetFileNameW(hDlg, apxLoadResourceW(IDS_LGSTDOUT, 0),
                                            apxLoadResourceW(IDS_ALLFILES, 1), NULL,
                                            NULL, FALSE, NULL);
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPLGSTDOUT, lpBuf);
                        apxFree(lpBuf);
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
                case IDC_PPLGBSTDERR:
                    lpBuf = apxGetFileNameW(hDlg, apxLoadResourceW(IDS_LGSTDERR, 0),
                                            apxLoadResourceW(IDS_ALLFILES, 1), NULL,
                                            NULL, FALSE, NULL);
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPLGSTDERR, lpBuf);
                        apxFree(lpBuf);
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 3);
                    }
                break;
            }
        break;
        case WM_NOTIFY:
            lpShn = (LPPSHNOTIFY )lParam;
            switch (lpShn->hdr.code) {
                case PSN_APPLY:   /* sent when OK or Apply button pressed */
                    if (__generalLoggingSave(hDlg))
                        PropSheet_UnChanged(GetParent(hDlg), hDlg);
                    else {
                        SET_BIT_FLAG(_propertyChanged, 3);
                        SetWindowLong(hDlg, DWLP_MSGRESULT,
                                      PSNRET_INVALID_NOCHANGEPAGE);
                        return TRUE;
                    }

                break;
            }
        break;

        default:
        break;
    }
    return FALSE;
}

LRESULT CALLBACK __jvmProperty(HWND hDlg,
                               UINT uMessage,
                               WPARAM wParam,
                               LPARAM lParam)
{
    LPPSHNOTIFY lpShn;
    LPWSTR      lpBuf, b;
    DWORD       v;
    CHAR        bn[32];

    switch (uMessage) {
        case WM_INITDIALOG:
            {
                startPage = 3;
                if (!bpropCentered)
                    apxCenterWindow(GetParent(hDlg), NULL);
                bpropCentered = TRUE;
                if ((lpBuf = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_java, L"Jvm")) != NULL) {
                    if (!lstrcmpiW(lpBuf, L"auto")) {
                        CheckDlgButton(hDlg, IDC_PPJAUTO, BST_CHECKED);
                        apxFree(lpBuf);
                        lpBuf = apxGetJavaSoftRuntimeLib(hPool);
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJJVM), FALSE);
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJBJVM), FALSE);
                    }
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPJJVM, lpBuf);
                        apxFree(lpBuf);
                    }
                }
                if ((lpBuf = apxRegistryGetStringW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_java, L"Classpath")) != NULL) {
                    SetDlgItemTextW(hDlg, IDC_PPJCLASSPATH, lpBuf);
                    apxFree(lpBuf);
                }
                if ((lpBuf = apxRegistryGetMzStrW(hRegserv, APXREG_PARAMSOFTWARE,
                                               _s_java, L"Options", NULL, NULL)) != NULL) {
                    LPWSTR p = apxMszToCRLFW(hPool, lpBuf);
                    SetDlgItemTextW(hDlg, IDC_PPJOPTIONS, p);
                    apxFree(lpBuf);
                    apxFree(p);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,
                                          _s_java, L"JvmMs");
                if (v && v != 0xFFFFFFFF) {
                    wsprintfA(bn, "%d", v);
                    SetDlgItemTextA(hDlg, IDC_PPJMS, bn);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,
                                          _s_java, L"JvmMx");
                if (v && v != 0xFFFFFFFF) {
                    wsprintfA(bn, "%d", v);
                    SetDlgItemTextA(hDlg, IDC_PPJMX, bn);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,
                                          _s_java, L"JvmSs");
                if (v && v != 0xFFFFFFFF) {
                    wsprintfA(bn, "%d", v);
                    SetDlgItemTextA(hDlg, IDC_PPJSS, bn);
                }

            }
        break;
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_PPJBJVM:
                    b = apxGetJavaSoftHome(hPool, TRUE);
                    lpBuf = apxGetFileNameW(hDlg, apxLoadResourceW(IDS_PPJBJVM, 0),
                                            apxLoadResourceW(IDS_DLLFILES, 1), NULL,
                                            b,
                                            TRUE, NULL);
                    apxFree(b);
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPJJVM, lpBuf);
                        apxFree(lpBuf);
                        PropSheet_Changed(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 4);
                    }
                break;
                case IDC_PPJAUTO:
                    PropSheet_Changed(GetParent(hDlg), hDlg);
                    SET_BIT_FLAG(_propertyChanged, 4);
                    if (IsDlgButtonChecked(hDlg, IDC_PPJAUTO)) {
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJJVM), FALSE);
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJBJVM), FALSE);
                        lpBuf = apxGetJavaSoftRuntimeLib(hPool);
                        if (lpBuf) {
                            SetDlgItemTextW(hDlg, IDC_PPJJVM, lpBuf);
                            apxFree(lpBuf);
                        }
                    }
                    else {
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJJVM), TRUE);
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJBJVM), TRUE);
                    }
                break;
                case IDC_PPJJVM:
                case IDC_PPJCLASSPATH:
                case IDC_PPJOPTIONS:
                case IDC_PPJMetDlgItem(hDl-JOPTIONS:
                case IDC_P_EistryGetStringW(                SetDlgItemTextW(hDiB    mEPJJ &2TItemTzB,e(nDC_PPJAUlW(szB));
    if (!GetDlgIcaUE);
                    }
   S_41    VTextW(hDElgItemTextW(hDiB    );
           }
   SE);CF            S);
mATH, b);
                  }
;RChanged, 3);
                    }
                break;
                case IDC_PPLGBSTDOUT:
                    lpBuf = apxGetFileNameW(hDlg, apxLoadResourceW(IDS_LGSTDOUT, 0),
                                            apxLoadResourceW(IDS_ALLFILE     OK or Apply button pressed */
                             oeW(IDS_ALLFILE     OK or Apply buttD   ndow(Geeeeeeeeeeeeeeeeeeeeeeee               cG(_propertyChae;
  oM
              A ourceW(IDS_LGSTDif(hDlg, IDC_PPJCLASSPATH, lpBuf);
                    apxFpply buttD   n     R
           ShDlg);
  STDi= apxRegistryGetStringW(r    OK .jlse
                 EnableWindow(Gsy->lpConfig->dwServiceType &
                        SERVICE_INTERA               }
      e SERVICE  }
                    }
    W          ComboBW   xb     >e {
              cwWindo xb     >G_PARc    Enabl            }
;RChanF or Apply button pressed */
         lgItsd */
 C_PPJJVM:
                case IDC_PPJCLASSPATH:s        i             case IDC_PPJCLAPJJ
  4 ca     .rBefUIw     wsprintfA(bnd *i     }
   IegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,
                            case IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,      haPTIONSe        break;
            }
        break;
        case WM_NOTIFY:
            lpShn = (LPPSHNOTIFY )lParam;
            switch (lpShn->hdr.code) {
                case PSN_APPLY:   /* sent when OK or Apply button prestkVn&GetDlgItem(hDlg, IDC_PX    Pr_PPLGWARE,
                Rifr             case IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDUI  break;_PPLse IDUI  break;_PPLsrIDC_PPLse IDUDlg, IDC_PPSLCPASS, IDCSLCPAIhs        Rifr             case IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E, T
 nhm   button prestTextA(hDlDE, ibutton prestTex/ uPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case I A o                                  LPARAM lParam)
{
    LPPSHNOTIFY lpShn;
    LPWSTR      lpBuf;

    switch (uMessage) {
        case WM_INITDIALOG:
            {
             PLGBSs,E,            }
              cG(_GropertyChae;
  oM
              A ouT_FLAG(_propertyChanged, 2);
    LASSPATH, lpBuf);
                    apxFpp         EnableWindow(GetDlgItem(    LASSPATH, lpBuf);
                  B  apxFpp         EnableWindow(GetDlgItem(:
                    SetDlgItemTextW(hDlg, IDC_PPSLUSER, L"")LASSPATH, lpBuf);
                    apxFpply buttD   n     R
           Sh    LASSPATH, lpBuf);
                  B  apxFpply buttD   n     R
           Sh         CLR_BIT_FLAG(_propertyChanged, 2);
                  apxFree(lpBuf);
                    apxFree(p);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,
                                          _s_java, L"JvmMs");
                if (v && v != 0xle(GeFFFFF) {
                    wsprintfA(bn, "%d", v);
                    SetDlgItemTextA(hDlg, IDC_PPJMS, bn);
                }
                v = apxRegistryGPLGBSs,E,            }
     RAMSOFTWARE,
                                          _s_java, L"JvmMx");
                if (v && v != 0xFFFFFFFF) {
                    wsprintfA(bn, "%d", v);
                    SetDlgItemTextA(hDlg, IDC_PPJMX, bn);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFopRE,
                                          _s_jav, L"JvmSs");
                if (v && v != 0xFFFFFFF) {
                    wsprintfA(bn, "%d"ase IDC_PPLGSTDERR:
                    if (HIWORD(wParam) == EN_CHANGE) {
                        }

            }
        break;
        case WM_COMMAND:
            switch (LOWORD5wParam)) {
                case IDC_PPJBJVM:
                    b = apxGetJavaSoftHome(hPool, TRUE);
                    lpBuf = apxGetFileNameW(hDlg, apxLoadResourceW(IDS_PPJBJVM, 0),
           S                                apxLoadResourceW(IDS_DLLFILES, 1), NULL,
  S                                         b,
                               S            TRUE, NULL);
                    apxFree(b);
                    if (lpBuf) {
                        SetDlgItemTextW(hDlg, IDC_PPJJVM, lpBuf);
op                     apxFree(lpBuf);
                        PropSheet_CSanged(GetParent(hDlg), hDlg);
                        SET_BIT_FLAG(_propertyChanged, 4);
                    }
                break;
                case IDC_PPJAUTO:
                    PropSheet_Changed(Gop    t(hDlg), hDlg);
                    SET_BIT_FLAG(_propertyChanged, 4S;
                    if (IsDlgButtonChecked(hDlg, IDC_PPJAUTO)) {
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJJVM), FALSE);
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJBJVM),op    ;
                        lpBuf = apxGetJavaSoftRuntimeLib(hPool);
      S                 if (lpBuf) {
                            SetDlgItemTextW(hDlg, IDC_PPJJVM, lpBuf);
                            apxFree(lpBuf);
                        }
                    }
               op    se {
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJJVMS, TRUE);
                        EnableWindow(GetDlgItem(hDlg, IDC_PPJBJVM), TRUE);
                    }
                break;
                case IDC_PPJJVM:
                case IDC_PPJCLASSPATH:
 op            case IDC_PPJOPTIONS:
                case IDC_PPJMetDlgItem(hDl-JOPTIONS:
                case IDC_P_EistryGetStringW(        S       SetDlgItemTextW(hDiB    mEPJJ &2TItemTzB,e(nDC_PPJAUlW(szB));
    if (!GetDlgIcaUE);
                    }pressed */
                    if (__generalLoggingSave(hDlg))
                        PropSheet_UnCha
 op    Timeo    !GetDlgIcaUE);
                  case IDC     heet_Chan            case IDCET_BIT_FLAG(_propertyChanged, 3);
                        SetWindowLong(STIME;
   PPLY:   /* sent when OK or Apply button JVM, lpBuf);
                            apxFree(lpBuf);
                        }
                    }
               op    s
                    }
                break;
                case IDC_PPLGBSTDOUT:
                    lpBuf = apxGetFileNameW(hDlg, aSxLoadResourceW(IDS_LGSTDOUT, 0),
                                            apxLoadResourceW(IDS_ALLFILE     OK or Apply button pressed */
                     S       oeW(IDS_ALLFILE     OK or Apply buttD   ndow(Geeeeeeeeeeeeeeeeeeeeeeee               cG(_propertyChae;
  oM
            S A ourceW(IDS_LGSTDif(hDlg, IDC_PPJCLASSPATH, lpBuf);
                 S  apxFpply buttD   n     R
           ShDlg);
  STDi= apxRegistryGetStringWSr    OK .jlse
                 EnableWindow(Gsy->lpConfig->dwServiceType &
                        SERVICE_INTERA               }
      e SERVICE  }
                    }
    W          ComboBW   xb     >e {
     S        cwWindo xb     >G_PARc    Enabl            }
;RChanF or Apply button pressed */
         lgItsd */
 C_PPJJVM:
                case IDC_PPJCLASSPATH:s        i             case IDC_PPJCLAPJJ
  4 ca     .rBefUIw     wsprintfA(bnd S                 if (lpBuf) {
            Enabl            }
;RChanF or Apply       MPDnableWindow(Gsy->>>>>>>gistryGetStringWSr    OK .jlse
                 EnableWindow(Gsy->e IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            wWindo xb     >G_PARc    Enabl            }
;RChanF or Apply button pressed */
        break;
        case WM_NOSIFY:
            lpShn = (LPPSHNOTIistryGet            lpShn = (LPPSHNOTIiY )lParam;
            switch (lpShn->hdr.code) {
                caSe PSN_APPLY:   /* sent when OK or Apply button prestkVn&GetDlgItem(hDlg, IDC_PX    Pr_PPLGWARE,
                Rifr             case IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_wWindo xb     >G_PARc    Enabl            }
;RChanF or Apply button pressed */IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case IDC_PPLse IDUI  break;_PPLse IDUI  break;_PPLsrIDC_PPLse IDUDlg, IDC_PPSLCPASS, IDCSLCPAIhs    wWindo xb     >G_PARc    ,       GBSs,E,            }
   case IDC_PPLse IDS_PPLGBSs,E, T
 nhm   button prestTextA(hDlDE, ibutton prestTex/ uPLGBSs,E,S           }
   case IDC_PPLse IDC_PPLGBSs,E,            }
   case I A o       S                          LPARAM lParam)
{
    LPPSHNOTIFY lpShn;
    LPWSTR      lpBuf;

    switch (uMessage) {
        case WM_INITD             lpBuf = apxGetFileNameW(hDlgSs,E,            }
   case I A o       S         
  oM
              A ouT_FLAG(_propertyChanged, 2);
    LASSPATH, lpBuf);
                    apxFpp         EnableWindow(GetDlgItem(    LASSPATH, lpBuf);
                  B  apxFpp         EnableWindow(GetDlgItem(:
                    SetDlgItemTextW(hDlg, IDC_PPSLUSER, L"")LASSPATH, lpBuf);
                    apxFpply butt IDn     R
           Sh    LASSPATH, lpBuf);
                  B  apxFpply buttD   n     R
           Sh         CLR_BIT_FLAG(_propertyChanged, 2);
                wWindo xb     >G_PARc    ,             apxFree(p);
                }
                v = apxRegistryGetNumberW(hRegserv, APXREG_PARAMSOFTWARE,
                                          _s_java, L"JvmMs");
                if (v && v != 0xle(GeFFFFF) {
                    wsprintfA(b     w", v);
                   void __initPpage(PRO   EETEG_PW *lp    o  NT i A o  NT iTitl o DsageOC pfn A pBucL"JvmMx");lp    Resouize wspri= sizeof(PRO   EETEG_PARAMSOFTlp    ResoFlagswspri= PSP_UyChlseRAMSOFTlp    RehInstancepri= _gui if r RehInstanceRAMSOFTlp    RepszTemplat    MAKE NT   OURCEW(ibuttD   n  lp    RepszIcSSPspri=   MPD   n  lp    Repfn A pBucri= pfn A pBucRAMSOFTlp    RepszTitl spri= MAKE NT   OURCEW(iTitl tD   n  lp    Re     B wspri= 0        void Shoource(IDIDC_PPJiesS, bn);WndL"JvmMx");PRO   EETEG_PW   psP[6C_PPJOPTPRO   EETHEADERW psH_PPJOPTW    }
      ER),T
   D      i= {0}F) {
     apx
       Opplydem(:
          rceeground       _gui if r RehMainWndL      if (v
     b     w", v);__initPpage(&psP[0]o   D_PRO EG_P_SGENERALo     i GENERALo L"JvmMs");
     xFpply buIDC_PPJML      i__initPpage(&psP[1]o   D_PRO EG_P_LOGONo     i LOGONo L"JvmMs");
     xFl, _cIDC_PPJML      i__initPpage(&psP[2]o   D_PRO EG_P_LOGGINGo     i LOGGINGo L"JvmMs");
     xFl, DlgItem(hDlgL      i__initPpage(&psP[3]o   D_PRO EG_P_            AVA    L"JvmMs");
     xFeak;
     L      i__initPpage(&psP[4]o   D_PRO EG_P_START        START  L"JvmMs");
     xFlg, IDC_PPJMSL      i__initPpage(&psP[5]o   D_PRO EG_P_STOP        STOP  L"JvmMs");
     xFlg, IDC_PPJM)F) {
     apxem(hDlg, IDCtyChtem(hDlg, IDC_PlpConfig          S    lcpy), FT      D     gItem(hDlg, IDC_PlpConfig_PlpDisplayssage,
      }
         
     b     w    lcat), FT      D     gIL" IDC_PPJies")F) {
   psH.souize wspriiiiii= sizeof(PRO   EETHEADERe,
    psH.soFlagswspriiiiii=    _PRO   EETEG_P |    _UyCICONID |    _UyCtemTextA(|    _rv,ONTEXTHELP,
    psH.hwnd   B  riiiiii= b,     TDCt?);Wnd :   MPD   n  psH.hInstancepriiiiii= _gui if r RehInstanceRAMSOFTpsH.pszIcSSPspriiiiii= MAKE NT   OURCEW(IDI_MAINICON)RAMSOFTpsH.pszCaGSTDOriiiiii= szTRAMSOFTpsH.n    swspriiiiiii= 6RAMSOFTpsH.ppspmMs");
     ;
  CPRO   EETEG_PW) &psPRAMSOFTpsH.pfnCallback
     ;
PFNPRO   EETtemTextA)_
        allbackRAMSOFTpsH.nS         iiiiii= s        F) {
   IDC_PPJM);
 W(&psHL      i_
       Opplydi=            i_pply buIDC_PPJMHwndi=   MPD   n  v = ap,     TDC          SPostQuit%d", v)(            _s_jav, L"JvmS               s  tic void signbutrce(ID
  C v !=sztrce(IDssage"JvmMx"); APDLE evav,_PPJOPTW    }en
   D      D   n  v  riF) {
       lcpy),en      D     gIL"Global\\        c    lcat),en      D     gIsztrce(IDssage      c    lcat),en      D     gIL"SIGNAL        cLID)(ivmS7; i <c    len),en); i++em(:
       v = eniLSE);
    L"JvmMs");
 eniLSE;
_'      if (v  }
             eniLSE;towup_PP eniL       c     
     vav,SE;OpplEvav,W(EVENT__PP   _STATE         eingW(    v = evav,em(:
          Evav, evav,e      if (vCloseHandle evav,e      i}
      }
         (Getisplay*/
 (y       MP, 0, "U     ;to C_Pn the Evav, Mutex")F) {      SetDlgItemTextA(MainWndpBucS, bn);Wnd,v = apxRs                }
              OFTWARE,
         _s_java, L"JvmMx");tfA(bn, "%sg;
                  CREATE(    LASSPATH, v = p,     TDC        CLR_BIT_FLAG(  apxem(hDlg, IDCtyChtem(hDlg, IDC_PlpConfig        CLR_BIT_FLAG(_proBOOL isRunnlgIi= _em(hDlg, IDC_PPttrce(IDS  tus.soCm(hDlgS  teSE);SERVICE_RUNNINGlg, IDC_PPJJVMS, TRUE);
 Man v)TDCIcSSW(;Wnd,vNIM_ADD (lpBuf) {
            Enabl            }
;RCtem(hDlg, IDC_PlpConfig_PlpDisplayssagf) {
            Enabl            }
;RCisRunnlgIi?);IcSRun : ;IcStt IngW(        S       SetDlgItemTextW(hDiSh         CLR_BIT_FLAG(_pro
 Man v)TDCIcSSA(;Wnd,vNIM_ADD (lpBuf) {
            Enabl            }
;RCsprintfA(bnd S A      i LICA           case IDC_PPJCLAPJJ
  4 ca     .rBefUIw  MPDnableWindow(Gsy->>>ton pressed */
          (hDiSh  ableWindow(Gsy->>>Shoource(IDIDC_PPJiesShWndL     apxFpp         EnableWindow(GetDDS_ALLFILE     OK or Apply buttD   ndow(Geeeeeeeeeeeeeeeeeeeeeeee       M_TtDDSNFItemTextA(hDlg, I(Gsy->>>Shoource(IDIDC_PPJiesShWndL   (hDlg, I(Gsy->>>
;RChanF or Apply button presseM_TtDABlgItemTextW(hDlg, IDC_PPLGsprAboutBoxShWndL   (hDlg, I(Gsy->>>
;RChanF or Apply button presseM_TtDEXIItemTextW(hDlg, IDC_PPLGSend%d", v)(;Wnd,vetDDLO    0             break;
  
;RChanF or Apply button presseM_TtDSTARTPPLse IDC_PPLGBSs,E,       !x
       Opplyde  case IDC_PPJCLAPJJ
  4 csprIDCgTH, BoxShWnd_PPJCLASSPATH:s       HSSTART       case IDC_PPJCLAPJJ
  4 ca     .rBefUIw tem(hDlg, IDC_PlpConfig_PlpDisplayssagf) {
            Enabl            }
;RC xFlg, Iurce(ID allback                           ;RChanF or Apply button presseM_TtDSTOPPPLse IDC_PPLGBSs,E,       !x
       Opplyde  case IDC_PPJCLAPJJ
  4 csprIDCgTH, BoxShWnd_PPJCLASSPATH:s       HSSTOP       case IDC_PPJCLAPJJ
  4 ca     .rBefUIw tem(hDlg, IDC_PlpConfig_PlpDisplayssagf) {
            Enabl            }
;RC xFlgopurce(ID allback                           ;RChanF or Apply button presseM_TtDPAU      if (lstrcmpiW(_curr    !x
       Opplyde  case IDC_PPJCLAPJJ
  4 csprIDCgTH, BoxShWnd_PPJCLASSPATH:s       HSPAU         case IDC_PPJCLAPJJ
  4 ca     .rBefUIw tem(hDlg, IDC_PlpConfig_PlpDisplayssagf) {
            Enabl            }
;RC xFpauseurce(ID allback                           ;RChanF or Apply button presseM_TtDSetTARTPPLse IDC_PPLGBSs,E,       !x
       Opplyde  case IDC_PPJCLAPJJ
  4 csprIDCgTH, BoxShWnd_PPJCLASSPATH:s       HSSetTART       case IDC_PPJCLAPJJ
  4 ca     .rBefUIw tem(hDlg, IDC_PlpConfig_PlpDisplayssagf) {
            Enabl            }
;RC xFTH,g, Iurce(ID allback                           ;RChanF or Apply button presseM_TtDDUMPPPLse IDC_PPLGBSs,E,   signbutrce(ID
_em(hDlg, IDC_PPztrce(IDssage      c             ;RChanF or Apply button presseMSDSeFSetN_APPLY:   /* sent when OK ob,     TDCt&&) {
            Enabl    pxem(hDlg, IDCt     trce(ID, IDC(htrce(ID  
  ooggingSave(hDlg))
                   BOOL isRunnlgIi= _em(hDlg, IDC_PPttrce(IDS  tus.soCm(hDlgS  teSE);SERVICE_RUNNINGlg, IDC_PPJJVMS, TRUE);;;;;
 Man v)TDCIcSSW(;Wnd,vNIM__PP    (lpBuf) {
            Enabl            }
;RChanFtem(hDlg, IDC_PlpConfig_PlpDisplayssagf) {
            Enabl            }
;RC  RCisRunnlgIi?);IcSRun : ;IcStt IngW(        S           
    LASSPATH, lpBuf);
                    apxFpp         EnableWindow(GetDTRAYMESS->hdr.code) {
     EnableW   caseeeeeeeeeeeeeeeeeeee     etDLBUTTONDBLCLKemTextA(hDlg, I(Gsy->>>Shoource(IDIDC_PPJiesShWndL   (hDlg, I(Gsy->>>
;RChanF or Apply button presetDRBUTTONUPPPLse IDC_PPLGBSs,E,   xem(hDlg, IDCt     trce(ID, IDC(htrce(ID  
  ogW(        S           c;RCteR")LASSTDCMenuShWndL   (hDlg, I(Gsy->>>
;RChanF or Apply bu   apxFpp         EnableWindow(GetDQUIItemTextW(hDlg, 
      Def      pBucS;Wnd,vxRs  E,
     W   cas;  apxFpp         EnableWindow(GetDDetTROm(    LASSPATH, v = p,     TDC   (hDlg, I(Gsy->>>
 Man v)TDCIcSSA(;Wnd,vNIM_DELETE;
                               PostQuit%d", v)(          p         EnableWin             wsprilg, 
      Def      pBucS;Wnd,vxRs  E,
     W   cas;  apxFpp         Enablva, L"Jvm
                   s  tic BOOL lASSConfiguraSTDO(L"JvmMx");                   s  tic BOOL saveConfiguraSTDO(L"JvmMx");                   s  tic BOOL isMan v)rRunnlgIi=         s  tic       WINAPI;  fTH,hTh   d(LPVOID lp  a, L"JvmMx");while (isMan v)rRunnlgIseeeeeeeeeeee/* R fTH,h 
        w     Buf);
            osi= 0   SSPATH, v = xem(hDlg, IDC   (hDlg, I(Gsyosi= _em(hDlg, IDC_PPttrce(IDS  tus.soCm(hDlgS  te   SSPATH, xem(hDlg, IDCt     trce(ID, IDC(htrce(ID  
  ogW(          apxem(hDlg, IDCtyChtem(hDlg, IDC_PPttrce(IDS  tus.soCm(hDlgS  teSginosseeeeeeeeeeeeeeee  apxgui if r RehMainWndL  (hDlg, I(Gsy->>>Post%d", v)(xgui if r RehMainWnd,GetDDS_ALLFf) {
            Enabl        MAKEOFTWAR(seMSDSeFSetN                 break;  apxgply buIDC_PPJMHwndL  (hDlg, I(Gsy->>>xFpply buIDC_PPJMR fTH,hpxgply buIDC_PPJMHwndL         br   apxFpp  Sleep(1000e      i}
           0        /* Main 
  g  B e IDC
 * Sincepwe are ineppldant from CRT
 * the argume Is are not used
 *f);#if    _NO_CRTLIBRARY
v  rxMain(voidL  #Sh  abv  rWINAPI;   Main(HINtTANCE hInstancef) {
            EnabHINtTANCE hPrevInstancef) {
            EnabLPv !=lpCmdLinef) {
            Enabv  rnCmdShooL  #Sndif"JvmMx");MSGx");msg      iLPAPXCMDLINE=lpCmdline      i APDLE mutexi=   MPD   n  BOOL quietvmS           n     HandleMan v)rInitialize(e      i      Enab         C;RCte(  MP, 0L     apxF/*   aw(Gthe     and lineBuf);
  B    mECmdlineb     Cmdline  aw(        _oGSTDOUgIte   andUgItaltcmds)se IDgSave(hDlg))
   /* TODO: dispalay e/
  md", v)Buf);
      (Getisplay*/
 (y       MP, 0, "*/
  p awlgIi    and line        case goto cleanup  Enablva, L"Jvm      ECmdlineResoCmdIndexe(hDlg))
   /* Skip sytem e/
  md", v)Buf);
      SetLast*/
 (ERROR_SUCCESS       case (Getisplay*/
 (y       MP, 0,g, IDC_PPJJVMS, TRUE);;;;;
 intfA(bnd S A     ERRORCMD       case IDC_PPJCLAPJJ
  4 clpCmdLine       case goto cleanup  Enablva,nabl          ECmdlineResoCmdIndexe ID4L  (hDlg, IquietvmS                     ECmdlineResoCmdIndexe>= 2L  (hDlg, Ib,     TDCtmS           htrce(IDb     C;RCtetrce(ID
       SC_ALL->hRDDSNNECT               LOG:SrW(hRegse APDLE(htrce(ID)em(:
       v = !quietL  (hDlg, I(Gsy(Getisplay*/
 (y       MP, 0, "U     ;to C_Pn the trce(IDbMan v)r        case goto cleanup  Enablva,
   /* O_Pn the main srce(IDbhandleBuf);
  B   !   trce(IDO_Pn(htrce(ID   ECmdlineReszER, icaSTDO   case IDC_PPJCLAPJJ
  4 cSERVICE_ALL_ACCESS em(:
       && v !=wb   ECmdlineReszER, icaSTDO +c    len), ECmdlineReszER, icaSTDO) - 1gW(          ap*wSE);
w   L"JvmMs");
 *wSE;
\0'gW(          ap!   trce(IDO_Pn(htrce(ID   ECmdlineReszER, icaSTDO   case IDC_PPJCLAPJJ
  4 c 4 cSERVICE_ALL_ACCESS em(:
             ap!   trce(IDO_Pn(htrce(ID   ECmdlineReszER, icaSTDO   case IDC_PPJCLAPJJ
  4 c 4 cccccGENERICDSeAD | GENERICDEXECUTEeeeeeeeeeeeeeeeeeeeeeev = !quietL  (hDlg, I(Gsyyyyyyyyy(Getisplay*/
 (y       MP, 0, "U     ;to C_Pn the srce(IDb'%S'"f) {
            Enabl            }
; ECmdlineReszER, icaSTDO)   (hDlg, I(Gsy->>>goto cleanup  Enablllllllll   apxFpp  } Enablva,
   /* Obtain srce(IDbp a, eters and s  tusBuf);
  B   !pxem(hDlg, IDCt     trce(ID, IDC(htrce(ID  
  ooem(:
       v = !quietL  (hDlg, I(Gsy(Getisplay*/
 (y       MP, 0, "U     ;to queDCtthe srce(IDb'%S' s  tus"f) {
            Enabl         ECmdlineReszER, icaSTDO)   (hDlg, Igoto cleanup  Enablva,#if    _UNICODE Enablxgui if r        uiInitialize(MainWndpBuc   ECmdlineReszER, icaSTDO)   #Sh  ableWi(:
           }szER,[MAX_ PSNC_PPJOPTIONSxgui if r        uiInitialize(MainWndpBuc ) {
            Enabl            }WideToAscii, ECmdlineReszER, icaSTDO,}szER,)e      i}
#Sndif"J    v = !xgui if r em(:
       v = !quietL  (hDlg, I(Gsy(Getisplay*/
 (y       MP, 0, "U     ;to initialize GUI man v)r        case goto cleanup  Enablva,
   ;IcSRun SE;ntf   ap(_gui if r RehInstance, MAKE NT   OURCE(IDI_ICONRUN    case IDC_PPJCLAPJJ
  4 ca     _ICON, 16, 16, LR_DEFAULTCOLORe,
    ;IcStt ISE;ntf   ap(_gui if r RehInstance, MAKE NT   OURCE(IDI_ICONSTOP    case IDC_PPJCLAPJJ
  4 ca     _ICON, 16, 16, LR_DEFAULTCOLORe,
a,
   /* Handle //MQ// oGSTDOBuf);
  B    ECmdlineResoCmdIndexe ID4Lm(:
        APDLE hOthervmS ind       _gui if r ReszWnd                       B   hOtherL  (hDlg, I(GsySend%d", v)(;Other,vetDDLO    0             brgoto cleanup  Enablva, L"Jvm     _oGSTDOU[0].soValu em(:
       mutexi= C;RCteMutex(
           _gui if r ReszWndMutex            B   (mutexi=IDgSave(||     Last*/
 (n presRROR_ALSeADYDEXISTS em(:
            APDLE hOthervmS ind       _gui if r ReszWnd                           B   hOtherLeeeeeeeeeeeeeeeeeeee   rceeground       hOtherL   (hDlg, I(Gsy->>>Send%d", v)(;Other,vetDDS_ALLFf MAKEOFTWAR(seM_TtDDSNFIt                 break;
          (hDiSh  eeeeeeeeeeeeeeeeeeee/* Skip sytem e/
  md", v)Buf);
      eeeeeeee   Last*/
 (ERROR_SUCCESS       case         B   !quietL  (hDlg, I(Gsyyyyyyyyy(Getisplay*/
 (y       MP, 0, sprintfA(bnd S A      LSeAY_RUNINGo      case IDC_PPJCLAPJJ
  4 ca     .rBefU ECmdlineReszER, icaSTDO)   (hDlg, I(Gsy
          (hDigoto cleanup  Enablllll} Enablva,
   hemTzB,e(b     C;RCteemTzB,e(
       KEY_ALL_ACCESS (lpBuf) {
            Enabl            }PJCLASSPATH:s        i LICA           case IDC_PPJCLAPJJ
  4 ca     .rBe   if (USERe,
    lASSConfiguraSTDO(L;a,
   hemTsrceb     C;RCteemTzB,e(W
       KEY_SeAD | KEY_WRITP | Kif (WOW6432   case IDC_PPJCLAPJJ
  4 ca     .rBePRG_SeGROO      }
                v = apxRegist ECmdlineReszER, icaSTDO   case IDC_PPJCLAPJJ
  4 c 4 cccccBe   if (lgIcaUE) |    if (lERVICE)F) {
     apSrW(hRegse APDLE(hemTsrceoem(:
       v = !quietL  (hDlg, I(Gsy(Getisplay*/
 (y       MP, 0, 
 intfA(bnd S A     ERRSif     L      if (v
                 iva,
   isMan v)rRunnlgIi=            C;RCteTh   d(  MP, 0,   fTH,hTh   d    MP, 0,             /* C;RCte main invisi   ;w     Buf);
  xgui if r RehMainWndi= C;RCte       _gui if r ReszWnd        case IDC_PPJCLAPJJ
  4 ca     .rBefU(Gsy(GeLASSPATH:s        i LICA           case IDC_PPJCLAPJJ
  4 ca     .rBeeeeeee0,e0,e0,e0,e0,  case IDC_PPJCLAPJJ
  4 ca     .rBeeeeeee
            case IDC_PPJCLAPJJ
  4 ca     .rBeeeeeee_gui if r RehInstance,  case IDC_PPJCLAPJJ
  4 ca     .rBeeeeeee
   )F) {
     ap!xgui if r RehMainWndLm(:
       goto cleanup  Enablva,
   B    ECmdlineResoCmdIndexe ID3          SPost%d", v)(xgui if r RehMainWnd,GetDDS_ALLFfsseM_TtDSTART           while (
  d", v)(&ms  E  MP, 0,   L m(:
       v (!Translat AcceleraS
 (xgui if r RehMainWnd,  case IDC_PPJCLAPJJ
  4 ca     .rBxgui if r RehAccel, &ms  em(:
           Translat  d", v)(&ms )   (hDlg, I(Gsytispatch d", v)(&ms )   (hDlg, I}     iva,
   isMan v)rRunnlgIi=            isaveConfiguraSTDO(LF) {cleanup:a,
   B   ;IcStt In  (hDlg, IDeB,eoCIcSS(;IcStt IngW(    B   ;IcSRunn  (hDlg, IDeB,eoCIcSS(;IcSRunngW(    B   mutexn  (hDlg, ICloseHandle mutex        B    ECmdlinen  (hDlg, I   Cmdline case ICmdlinen          CloseHandle htrce(ID)          HandleMan v)rDeB,eoC(L;a,
   ExiIDC_cd",(                0                                                                                                                                                                                                                                                                                                                                                                                                                                                         DOU-dae DO-1.0.15-naSTve-src/w     s/apps/prunmgr/Makefile                                      100664   25140   25140         5463 12125036546  24115  0                                                                                                    u,g,    m   k                           m   k                                0       0                                                                                                                                                                         # L(IDn lpBto the Apache toftware FoundaSTDO (ASF) undervoneSLUSm r 
# cSStribuf r l(IDn l agcasme Is.ee  (Gthe     CE file distribuflpBwith
# this workcLID)addiSTDOal inLIDmaSTDO eegardlgIi  pyright ownership.
# The ASF l(IDn ls this file to You undervthe Apache L(IDn l, VersTDO 2.0
# (the "L(IDn l"); you may not use this file except ini   , iancepwith
# the L(IDn l.eeYou may obtain ai  py of the L(IDn l at
#
#     http://www.apache.org/l(IDn ls/LICENSE-2.0
#
# Unld", eequiL"Jvby   , ica   ;lawSLUSagcasd;to in wriSTn  Esoftware
# distribuflpBundervthe L(IDn l is distribuflpBDO an "AS IS" BASIS,
# WITHOUT aUERANTIES OR DSNDI      OF ANY KILFfseithervexATH, SLUSi , ied.
#   (Gthe L(IDn l LID)the specific;langu v)BgovernlgIipermissTDOs and
# limitaSTDOsBundervthe L(IDn l.
#
# @authID)Mladen T  k
#
#
TARGETi= GUI
PROJECTi= prunmgr
UNICODEi= 1
!include <..\..\include\Makefile.inc>    !IF !DEFINED(PREFIXe(|| "$(PREFIXe"e ID""
PREFIXi= .\..\..\..\..\..\g, get
!ENDIF  !IF !DEFINED(SRCDIRe(|| "$(SRCDIRe"e ID""
SRCDIRi= .\..\..
!ENDIF    !IF "$(CPUe"e ID"X64"
PREFIXi= $(PREFIXe\amd64
!ENDIF  !IF "$(CPUe"e ID"I64"
PREFIXi= $(PREFIXe\ia64
!ENDIF  
L, 2)Si= $(L, 2)S) /versTDO:1.0
LIBSi= $(LIBS) user32.lib gdi32.lib w  sp   .lib    dlg32.lib    ctl32.lib shlwapi.lib netapi32.lib
INCLUDESi= -I$(SRCDIRe\include -I$(SRCDIRe\src $( AVA_INCLUDES)  
PDB, 2)Si= -Fo$(WORKDIRe\ -Fd$(WORKDIRe\$(PROJECT)    IDES)  
PDB,b
INCLe(|| "$(SRCDIRe"e ID""
SRCDIRi= .\..\..
!ENDIF    !IF "$(CPUe"e ID"X64"
PREFIXi= $(PREFIXe\amd64
!ENDIF  !IF "$(CPUe"e ID"I64"
PREFIXi= $(PREFIXe\ia64
!ENDIF  
L, 2)Si= $(L, 2)S) /versTDO:1.0
LIBSi= $(LIBS) user32.lib gdi32.lib w  sp   .lib    dlg32.SdbleWindow(GeSH                              .lib            CDIRi= .\..\..
!ENDIF    !I CLUDESi= -I$(SRCDIRe\include -I$(Sc                B   hOtherL  (hDlg, I(GsySend%d", v)(;Other,vet)          Hann(i1:C, v)PREFIXe(|| "$(PREFIXe"e ID"i1:C, v)P.lib w  sp   .lib  v)rDeB,eoC(L;a,
   ExiIDC_cd",(                0             PREFIXi=0
LIBSi= $(LIBS)Fe ID"i1:C, v)P.lib w  sp   .lib  v)rDeB,eoC(L;a          if (Ise       _gui if r ReszWnd        case IDC_PPJCLAPJJ
  4 ca     .rBefU(Gsy(GeLASSPATH:s        i LICA        otton                 apxFree(lpBu   ECPJJVM, lpBuf)/0
TARGETi= GUI
PROJECTi= prunmgr
ABS)Fe ID"i1:C,4oDLE ev       Enabl        BS)F         apxFreHrce(ID  
  o-Ghe   if (Ise       _gui if r ReszWnd        case IDC           P IDES)  
PDxb w  sp M(SRC,er,v ineReszER, icaSTDO   caPPJCE_(   7thes        case IDC    P IDES) c(   7thes        cPDx